import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-perform-activity',
  templateUrl: './perform-activity.component.html',
  styleUrls: ['./perform-activity.component.css']
})
export class PerformActivityComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
